ASSETS FOLDER
─────────────────────────────────────────────────────────────────

Place the following files here:

  resume-placeholder.pdf
    → Rename your actual resume to: resume-placeholder.pdf
    → Or update the href in index.html to your actual filename.

  img/profile.jpg (optional)
    → Your profile photo (recommended: square, at least 400×400px)
    → To use it, replace the .image-placeholder div in index.html
      with: <img src="assets/img/profile.jpg" alt="Lars Steve" />

  img/capstone-screenshot.png (optional)
    → Screenshot of your capstone project
    → Replace the .project-img-placeholder div in the featured
      project section with:
      <img src="assets/img/capstone-screenshot.png" alt="[Project Name]" />

  img/project-*.png (optional)
    → Screenshots for other project cards
    → Same pattern: replace .project-img-placeholder divs

─────────────────────────────────────────────────────────────────
